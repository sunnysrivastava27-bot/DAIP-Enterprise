import { motion } from "framer-motion";
import { Cpu, ShieldCheck } from "lucide-react";

import PerspectiveGrid from "../../svg/PerspectiveGrid";
import RoadNetwork from "../../svg/RoadNetwork";
import BuildingLayer from "../../svg/BuildingLayer";
import GlowLayer from "../../svg/GlowLayer";
import ScanLines from "../../svg/ScanLines";
import IntelligenceNodes from "../../svg/IntelligenceNodes";

const departmentStats = [
  {
    title: "Connected Departments",
    value: "26",
    status: "+3 this month",
    color: "text-emerald-400",
  },
  {
    title: "Live Data Streams",
    value: "148",
    status: "Real-time synchronized",
    color: "text-cyan-400",
  },
  {
    title: "System Health",
    value: "99.98%",
    status: "All services operational",
    color: "text-emerald-400",
  },
];

export default function DigitalTwin() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.45 }}
      className="rounded-3xl border border-cyan-500/20 bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 p-8 shadow-2xl"
    >
      {/* ======================================================
          HEADER
      ======================================================= */}

      <div className="flex items-center justify-between">

        <div>

          <div className="flex items-center gap-3">

            <Cpu className="h-6 w-6 text-cyan-400" />

            <span className="text-xs uppercase tracking-[0.30em] text-cyan-400">

              EXECUTIVE DIGITAL TWIN

            </span>

          </div>

          <h2 className="mt-3 text-3xl font-bold text-white">

            Development Authority

          </h2>

          <p className="mt-3 max-w-xl leading-7 text-slate-400">

            Live executive visualization of the Development Authority
            powered by the DAIP Intelligence Engine.

          </p>

        </div>

        <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/10 px-5 py-4">

          <div className="flex items-center gap-2">

            <ShieldCheck className="h-5 w-5 text-emerald-400" />

            <span className="font-semibold text-emerald-400">

              LIVE SYNC

            </span>

          </div>

        </div>

      </div>

      {/* ======================================================
          EXECUTIVE DIGITAL TWIN
      ======================================================= */}

      <div className="relative mt-10 h-[520px] overflow-hidden rounded-3xl border border-cyan-500/20 bg-[#050B14]">

        {/* Background */}

        <div className="absolute inset-0 bg-gradient-to-b from-slate-900 via-slate-950 to-[#02060d]" />

        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(34,211,238,0.10),transparent_70%)]" />

        {/* SVG LAYERS */}

        <GlowLayer />

        <PerspectiveGrid />

        <RoadNetwork />

        <BuildingLayer />

        <ScanLines />

        <IntelligenceNodes />
		        {/* ======================================================
            EXECUTIVE TITLE
        ======================================================= */}

        <div className="absolute left-8 top-6 z-20">

          <p className="text-xs uppercase tracking-[0.30em] text-cyan-400">

            CITY DIGITAL TWIN

          </p>

          <h3 className="mt-2 text-2xl font-bold text-white">

            Development Authority Command Center

          </h3>

          <p className="mt-2 max-w-sm text-sm text-slate-400">

            Executive visualization of all planning, engineering,
            finance, property and citizen services.

          </p>

        </div>

        {/* ======================================================
            LIVE STATUS
        ======================================================= */}

        <motion.div
          animate={{
            scale: [1, 1.04, 1],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
          }}
          className="absolute right-8 top-6 z-20 rounded-2xl border border-emerald-500/20 bg-emerald-500/10 px-5 py-4 backdrop-blur-xl"
        >

          <p className="text-xs uppercase tracking-[0.20em] text-emerald-400">

            LIVE MODEL

          </p>

          <h3 className="mt-2 text-2xl font-bold text-white">

            ACTIVE

          </h3>

          <p className="mt-1 text-sm text-slate-400">

            Real-Time Synchronization

          </p>

        </motion.div>

        {/* ======================================================
            GOVERNMENT ASSETS
        ======================================================= */}

        <div className="absolute bottom-6 left-6 z-20 rounded-2xl border border-slate-800 bg-slate-900/80 px-6 py-5 backdrop-blur-xl">

          <p className="text-xs uppercase tracking-[0.20em] text-slate-500">

            Government Assets

          </p>

          <h3 className="mt-2 text-3xl font-bold text-white">

            26 Departments

          </h3>

          <p className="mt-2 text-sm text-emerald-400">

            Fully Integrated

          </p>

        </div>

        {/* ======================================================
            DIGITAL TWIN HEALTH
        ======================================================= */}

        <div className="absolute bottom-6 right-6 z-20 rounded-2xl border border-cyan-500/20 bg-cyan-500/10 px-6 py-5 backdrop-blur-xl">

          <p className="text-xs uppercase tracking-[0.20em] text-cyan-400">

            Digital Twin Health

          </p>

          <h3 className="mt-2 text-3xl font-bold text-white">

            99.98%

          </h3>

          <p className="mt-2 text-sm text-cyan-300">

            Operational

          </p>

        </div>

      </div>

      {/* ======================================================
          FOOTER METRICS
      ======================================================= */}

      <div className="mt-8 grid grid-cols-3 gap-6">

        {departmentStats.map((item) => (

          <div
            key={item.title}
            className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5"
          >

            <p className="text-xs uppercase tracking-[0.20em] text-slate-500">

              {item.title}

            </p>

            <h3 className="mt-3 text-3xl font-bold text-white">

              {item.value}

            </h3>

            <p className={`mt-2 text-sm ${item.color}`}>

              {item.status}

            </p>

          </div>

        ))}
		      </div>

    </motion.div>
  );
}
