import { motion } from "framer-motion";
import {
  Sparkles,
  AlertCircle,
  Clock3,
  TrendingUp,
  Play,
} from "lucide-react";

export interface HeroGreetingData {
  greeting: string;
  chairmanName: string;
  description: string;

  decisionsAwaiting: number;
  estimatedReviewTime: string;
  revenueOpportunity: string;
}

export interface HeroGreetingProps {
  data: HeroGreetingData;
  onStartBriefing?: () => void;
}

export default function HeroGreeting({
  data,
  onStartBriefing,
}: HeroGreetingProps) {
  const kpis = [
    {
      icon: AlertCircle,
      iconColor: "text-amber-400",
      value: data.decisionsAwaiting.toString(),
      label: "Decisions Awaiting",
    },
    {
      icon: Clock3,
      iconColor: "text-cyan-400",
      value: data.estimatedReviewTime,
      label: "Estimated Review Time",
    },
    {
      icon: TrendingUp,
      iconColor: "text-emerald-400",
      value: data.revenueOpportunity,
      label: "Revenue Opportunity",
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45 }}
      className="flex h-full flex-col"
    >
      {/* Executive Intelligence Briefing */}

      <div className="inline-flex w-fit items-center gap-2 rounded-full border border-cyan-500/20 bg-cyan-500/10 px-4 py-2">

        <Sparkles className="h-4 w-4 text-cyan-300" />

        <span className="text-[11px] font-semibold uppercase tracking-[0.24em] text-cyan-300">
          Executive Intelligence Briefing
        </span>

      </div>

      {/* Greeting */}

      <div className="mt-8">

        <h1 className="text-[48px] font-bold leading-[1.02] tracking-[-0.04em]">

          <span className="block text-white">
            {data.greeting},
          </span>

          <span className="mt-2 block bg-gradient-to-r from-cyan-300 via-sky-400 to-emerald-400 bg-clip-text text-transparent">
            {data.chairmanName}
          </span>

        </h1>

      </div>

      {/* Description */}

      <p className="mt-6 max-w-[640px] text-[17px] leading-8 text-slate-400">
        {data.description}
      </p>

      {/* KPI Row */}
	        <div className="mt-10 flex flex-wrap items-start gap-10">

        {kpis.map((item) => {
          const Icon = item.icon;

          return (
            <div
              key={item.label}
              className="flex items-start gap-3"
            >
              <div
                className={`mt-1 flex h-10 w-10 items-center justify-center rounded-full bg-slate-800/70 ${item.iconColor}`}
              >
                <Icon className="h-5 w-5" />
              </div>

              <div className="flex flex-col">

                <span className="text-xl font-semibold text-white">
                  {item.value}
                </span>

                <span className="mt-1 text-sm text-slate-400">
                  {item.label}
                </span>

              </div>
            </div>
          );
        })}

      </div>

      {/* Start Executive Briefing Button */}

      <div className="mt-10">

        <button
          type="button"
          onClick={onStartBriefing}
          className="group flex w-full items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-sky-600 px-6 py-4 text-base font-semibold text-white shadow-lg shadow-cyan-500/20 transition-all duration-300 hover:scale-[1.01] hover:shadow-cyan-500/30 active:scale-[0.99]"
        >
          <Play className="h-5 w-5 fill-current transition-transform duration-300 group-hover:translate-x-0.5" />

          <span>
            Start Executive Briefing
          </span>

        </button>

      </div>

    </motion.div>
  );
}