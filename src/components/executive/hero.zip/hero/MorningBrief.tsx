import { motion } from "framer-motion";
import {
  Sparkles,
  BrainCircuit,
  CalendarDays,
  Clock3,
  ShieldCheck,
  TrendingUp,
} from "lucide-react";

export default function MorningBrief() {
  const currentDate = new Date().toLocaleDateString("en-IN", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const currentTime = new Date().toLocaleTimeString("en-IN", {
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <motion.div
      initial={{ opacity: 0, x: 25 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.45 }}
      className="rounded-3xl border border-cyan-500/20 bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 p-7 shadow-2xl"
    >
      {/* ======================================================
          HEADER
      ======================================================= */}

      <div className="flex items-center justify-between">

        <div className="flex items-center gap-3">

          <div className="rounded-xl bg-cyan-500/15 p-3">

            <BrainCircuit className="h-6 w-6 text-cyan-400" />

          </div>

          <div>

            <span className="text-xs uppercase tracking-[0.3em] text-cyan-400">
              Executive Morning Brief
            </span>

            <h2 className="mt-1 text-2xl font-bold text-white">
              AI Intelligence Summary
            </h2>

          </div>

        </div>

        <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-3">

          <div className="flex items-center gap-2">

            <ShieldCheck className="h-5 w-5 text-emerald-400" />

            <span className="font-semibold text-emerald-400">
              98.7% Confidence
            </span>

          </div>

        </div>

      </div>

      {/* ======================================================
          DATE & TIME
      ======================================================= */}

      <div className="mt-8 grid grid-cols-2 gap-4">

        <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4">

          <div className="flex items-center gap-3">

            <CalendarDays className="h-5 w-5 text-cyan-400" />

            <div>

              <p className="text-xs uppercase tracking-[0.2em] text-slate-500">
                Today
              </p>

              <p className="mt-1 text-sm font-medium text-white">
                {currentDate}
              </p>

            </div>

          </div>

        </div>

        <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4">

          <div className="flex items-center gap-3">

            <Clock3 className="h-5 w-5 text-cyan-400" />

            <div>

              <p className="text-xs uppercase tracking-[0.2em] text-slate-500">
                Current Time
              </p>

              <p className="mt-1 text-sm font-medium text-white">
                {currentTime}
              </p>

            </div>

          </div>

        </div>

      </div>

      {/* ======================================================
          AI SUMMARY
      ======================================================= */}

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.15 }}
        className="mt-8 rounded-2xl border border-cyan-500/20 bg-cyan-500/10 p-6"
      >

        <div className="flex items-center gap-3">

          <Sparkles className="h-6 w-6 text-cyan-400" />

          <h3 className="text-lg font-semibold text-white">
            Chairman's Executive Summary
          </h3>

        </div>

        <p className="mt-5 leading-7 text-slate-300">
          Good morning. Overall authority performance remains stable with
          strong revenue collection and healthy project execution. Citizen
          services are operating normally. Three infrastructure projects
          require executive attention today due to approaching milestone
          deadlines.
        </p>

      </motion.div>

      {/* ======================================================
          TODAY'S HIGHLIGHTS
      ======================================================= */}

      <div className="mt-8">

        <div className="flex items-center gap-3">

          <TrendingUp className="h-5 w-5 text-emerald-400" />

          <h3 className="text-lg font-semibold text-white">
            Today's Highlights
          </h3>

        </div>
		        <div className="mt-5 space-y-4">

          <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-4">

            <div className="flex items-start gap-3">

              <div className="mt-1 h-3 w-3 rounded-full bg-emerald-400" />

              <div>

                <h4 className="font-semibold text-white">
                  Revenue Collection
                </h4>

                <p className="mt-1 text-sm leading-6 text-slate-300">
                  Revenue collection has reached
                  <span className="font-semibold text-emerald-400">
                    {" "}92%
                  </span>
                  of the monthly target. Property tax receipts continue to
                  outperform forecasts.
                </p>

              </div>

            </div>

          </div>

          <div className="rounded-2xl border border-amber-500/20 bg-amber-500/10 p-4">

            <div className="flex items-start gap-3">

              <div className="mt-1 h-3 w-3 rounded-full bg-amber-400" />

              <div>

                <h4 className="font-semibold text-white">
                  Project Monitoring
                </h4>

                <p className="mt-1 text-sm leading-6 text-slate-300">
                  Three major infrastructure projects are approaching their
                  scheduled milestone dates and require executive review within
                  the next 48 hours.
                </p>

              </div>

            </div>

          </div>

          <div className="rounded-2xl border border-red-500/20 bg-red-500/10 p-4">

            <div className="flex items-start gap-3">

              <div className="mt-1 h-3 w-3 rounded-full bg-red-400" />

              <div>

                <h4 className="font-semibold text-white">
                  Citizen Complaints
                </h4>

                <p className="mt-1 text-sm leading-6 text-slate-300">
                  Complaint resolution has improved to
                  <span className="font-semibold text-red-300">
                    {" "}96%
                  </span>,
                  however 12 high-priority cases remain pending and should be
                  reviewed today.
                </p>

              </div>

            </div>

          </div>

        </div>

      </div>

      {/* ======================================================
          TODAY'S PRIORITIES
      ======================================================= */}

      <div className="mt-8 rounded-2xl border border-slate-800 bg-slate-900/70 p-6">

        <h3 className="text-lg font-semibold text-white">
          Priority Actions
        </h3>

        <div className="mt-5 space-y-4">

          <div className="flex items-start gap-3">

            <div className="mt-2 h-2.5 w-2.5 rounded-full bg-cyan-400" />

            <p className="text-sm leading-6 text-slate-300">
              Review delayed Smart Road Corridor progress report.
            </p>

          </div>

          <div className="flex items-start gap-3">

            <div className="mt-2 h-2.5 w-2.5 rounded-full bg-violet-400" />

            <p className="text-sm leading-6 text-slate-300">
              Approve today's land allotment recommendations.
            </p>

          </div>

          <div className="flex items-start gap-3">

            <div className="mt-2 h-2.5 w-2.5 rounded-full bg-emerald-400" />

            <p className="text-sm leading-6 text-slate-300">
              Review revenue collection performance across all zones.
            </p>

          </div>

          <div className="flex items-start gap-3">

            <div className="mt-2 h-2.5 w-2.5 rounded-full bg-orange-400" />

            <p className="text-sm leading-6 text-slate-300">
              Monitor emergency response and citizen grievance dashboard.
            </p>

          </div>

        </div>

      </div>
	        {/* ======================================================
          EXECUTIVE ACTIONS
      ======================================================= */}

      <div className="mt-8 grid grid-cols-3 gap-4">

        <motion.button
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.98 }}
          className="rounded-2xl border border-cyan-500/20 bg-cyan-500/10 p-4 text-left transition-all hover:border-cyan-400/40 hover:bg-cyan-500/20"
        >

          <Sparkles className="h-6 w-6 text-cyan-400" />

          <h4 className="mt-4 font-semibold text-white">
            Read Full Brief
          </h4>

          <p className="mt-2 text-sm leading-6 text-slate-400">
            Open the complete AI-generated executive briefing.
          </p>

        </motion.button>

        <motion.button
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.98 }}
          className="rounded-2xl border border-violet-500/20 bg-violet-500/10 p-4 text-left transition-all hover:border-violet-400/40 hover:bg-violet-500/20"
        >

          <BrainCircuit className="h-6 w-6 text-violet-400" />

          <h4 className="mt-4 font-semibold text-white">
            Voice Brief
          </h4>

          <p className="mt-2 text-sm leading-6 text-slate-400">
            Listen to a 2-minute AI executive briefing.
          </p>

        </motion.button>

        <motion.button
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.98 }}
          className="rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-4 text-left transition-all hover:border-emerald-400/40 hover:bg-emerald-500/20"
        >

          <TrendingUp className="h-6 w-6 text-emerald-400" />

          <h4 className="mt-4 font-semibold text-white">
            Export PDF
          </h4>

          <p className="mt-2 text-sm leading-6 text-slate-400">
            Download today's executive briefing report.
          </p>

        </motion.button>

      </div>

      {/* ======================================================
          FOOTER
      ======================================================= */}

      <div className="mt-8 flex items-center justify-between rounded-2xl border border-slate-800 bg-slate-900/70 px-6 py-5">

        <div>

          <p className="text-xs uppercase tracking-[0.2em] text-slate-500">
            Last AI Analysis
          </p>

          <p className="mt-2 text-sm text-white">
            Updated 2 minutes ago • All connected departments synchronized
          </p>

        </div>

        <div className="flex items-center gap-2 rounded-full border border-emerald-500/20 bg-emerald-500/10 px-4 py-2">

          <div className="h-2.5 w-2.5 rounded-full bg-emerald-400" />

          <span className="text-sm font-medium text-emerald-400">
            Live Intelligence
          </span>

        </div>

      </div>

    </motion.div>
  );
}
