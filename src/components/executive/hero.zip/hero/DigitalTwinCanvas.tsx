import { motion } from "framer-motion";

import GlowLayer from "../../svg/GlowLayer";
import PerspectiveGrid from "../../svg/PerspectiveGrid";
import RoadNetwork from "../../svg/RoadNetwork";
import BuildingLayer from "../../svg/BuildingLayer";
import ScanLines from "../../svg/ScanLines";
import IntelligenceNodes from "../../svg/IntelligenceNodes";

const DigitalTwinCanvas = () => {
  return (
    <div className="relative w-full h-full overflow-hidden rounded-2xl bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">

      {/* Ambient Background */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.12),transparent_70%)]" />

      <motion.div
        initial={{ opacity: 0, scale: 0.97 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8 }}
        className="relative w-full h-full"
      >
        <svg
          viewBox="0 0 1000 650"
          preserveAspectRatio="xMidYMid meet"
          className="w-full h-full"
        >
          {/* Background Glow */}
          <GlowLayer />

          {/* Perspective Grid */}
          <PerspectiveGrid />

          {/* Roads */}
          <RoadNetwork />

          {/* Buildings */}
          <BuildingLayer />

          {/* Animated Scan */}
          <ScanLines />

          {/* Intelligence Nodes */}
          <IntelligenceNodes />
        </svg>
      </motion.div>
    </div>
  );
};

export default DigitalTwinCanvas;